# Pyarmor 9.2.5 (trial), 000000, 2026-06-15T11:27:25.330419
from .pyarmor_runtime import __pyarmor__
